import { Component, OnInit, ViewChild, AfterViewInit, AfterContentInit, AfterViewChecked, ChangeDetectorRef } from '@angular/core';
import { SelecaoComponent } from './components/selecao/selecao.component';
import { CampeonatoComponent } from './components/campeonato/campeonato.component';
import { Filme } from './models/filme';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewChecked {
  @ViewChild(SelecaoComponent) selecaoComp;
  @ViewChild(CampeonatoComponent) campeonatoComp;

  titulo: string = "";
  descricao: string = "";
  flagComponenteSelecao: boolean = true;
  filmes: Array<Filme>;

  constructor(private changeDetector : ChangeDetectorRef) {
    this.filmes = new Array<Filme>();
  }

  ngAfterViewChecked(): void {
    this.atualizarDados();
    this.changeDetector.detectChanges();
  }

  gerarCampeonato($event: Array<Filme>): void {
    this.filmes = $event;
    this.flagComponenteSelecao = false;
  }

  atualizarDados(): void {
    if(this.flagComponenteSelecao) {
      this.atualizarDadosComSelecao();
    } else {
      this.atualizarDadosComCampeonato();
    }
  }

  atualizarDadosComSelecao(): void {
    this.titulo = this.selecaoComp.model.titulo;
    this.descricao = this.selecaoComp.model.descricao;
  }

  atualizarDadosComCampeonato(): void {
    this.titulo = this.campeonatoComp.model.titulo;
    this.descricao = this.campeonatoComp.model.descricao;
  }
}
