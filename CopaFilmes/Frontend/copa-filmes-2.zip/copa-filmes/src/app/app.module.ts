import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SelecaoComponent } from './components/selecao/selecao.component';
import { CampeonatoComponent } from './components/campeonato/campeonato.component';
import { SelecaoFilmeComponent } from './components/selecao-filme/selecao-filme.component';
import { CampeonatoFilmeComponent } from './components/campeonato-filme/campeonato-filme.component';

@NgModule({
  declarations: [
    AppComponent,
    SelecaoComponent,
    CampeonatoComponent,
    SelecaoFilmeComponent,
    CampeonatoFilmeComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
