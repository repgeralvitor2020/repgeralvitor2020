export abstract class ModelBase {
    titulo: string;
    descricao: string;
}