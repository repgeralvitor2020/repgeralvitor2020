import { Filme } from './filme';
import { ModelBase } from './model-base';

export class Campeonato extends ModelBase {
    titulo: string = 'Resultado Final';
    descricao: string = 'Veja o resultado final do Campeonato de filmes de forma simples e rápida.';
    filmes: Array<Filme>;

    constructor() {
        super();
        this.filmes = new Array<Filme>();
    }
}