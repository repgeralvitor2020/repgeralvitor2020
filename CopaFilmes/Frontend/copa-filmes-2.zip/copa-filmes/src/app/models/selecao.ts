import { Filme } from './filme';
import { ModelBase } from './model-base';

export class Selecao extends ModelBase {
    titulo: string = 'Fase de Seleção';
    descricao: string = 'Selecione 8 filmes que você deseja que entrem na competição e depois pressione o botão Gerar Meu Campeonato para prosseguir.';
    filmes: Array<Filme>;
    filmesSelecionados: Array<Filme>;
    filmesTotal: number = 0;
    flagGerarCampeonato: boolean = false;

    constructor() {
        super();
        this.filmes = new Array<Filme>();
        this.filmesSelecionados = new Array<Filme>();
    }
}