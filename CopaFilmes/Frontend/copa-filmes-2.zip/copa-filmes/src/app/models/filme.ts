export class Filme {
    id: string;
    titulo: string;
    ano: number;
    nota: number;
    selecionado: boolean;
}