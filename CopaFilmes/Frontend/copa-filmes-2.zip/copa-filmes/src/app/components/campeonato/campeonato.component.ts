import { Component, OnInit, Input } from '@angular/core';
import { Campeonato } from 'src/app/models/campeonato';
import { Filme } from 'src/app/models/filme';
import { ApiResponse } from 'src/app/models/api-response';
import { CopaFilmesService } from 'src/app/services/copa-filmes.service';

@Component({
  selector: 'app-campeonato',
  templateUrl: './campeonato.component.html',
  styleUrls: ['./campeonato.component.css']
})
export class CampeonatoComponent implements OnInit {
  model: Campeonato;

  @Input() filmes : Array<Filme>;

  constructor(private copaFilmesService: CopaFilmesService) {
    this.model = new Campeonato();
  }

  ngOnInit(): void {
    this.carregarFilmesCampeonato();
  }

  carregarFilmesCampeonato(): void {
    this.copaFilmesService
        .gerarCampeonato(this.filmes)
        .subscribe((filmes: ApiResponse<Array<Filme>>) => {
      this.model.filmes = filmes.data;
    });
  }
}
