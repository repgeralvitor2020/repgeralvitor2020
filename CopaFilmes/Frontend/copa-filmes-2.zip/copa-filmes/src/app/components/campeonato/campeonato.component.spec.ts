import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { campeonatoComponent } from './campeonato.component';

describe('campeonatoComponent', () => {
  let component: campeonatoComponent;
  let fixture: ComponentFixture<campeonatoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ campeonatoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(campeonatoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
