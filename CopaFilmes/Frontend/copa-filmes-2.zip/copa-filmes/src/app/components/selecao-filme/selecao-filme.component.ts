import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Filme } from '../../models/filme';

@Component({
  selector: 'app-selecao-filme',
  templateUrl: './selecao-filme.component.html',
  styleUrls: ['./selecao-filme.component.css']
})
export class SelecaoFilmeComponent implements OnInit {
  @Input() id : number;
  @Input() model : Filme;

  @Output() eventoSelecionar = new EventEmitter<Filme>();

  constructor() {}

  ngOnInit(): void {

  }

  selecionar(): void {
    this.model.selecionado = !this.model.selecionado;
    this.eventoSelecionar.emit(this.model);
  }
}
