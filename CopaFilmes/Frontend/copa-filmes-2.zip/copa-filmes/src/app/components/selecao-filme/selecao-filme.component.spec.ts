import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelecaoFilmeComponent } from './selecao-filme.component';

describe('SelecaoFilmeComponent', () => {
  let component: SelecaoFilmeComponent;
  let fixture: ComponentFixture<SelecaoFilmeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelecaoFilmeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelecaoFilmeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
