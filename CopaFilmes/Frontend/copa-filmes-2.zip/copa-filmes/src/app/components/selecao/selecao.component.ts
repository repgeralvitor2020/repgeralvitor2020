import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Filme } from '../../models/filme';
import { Selecao } from 'src/app/models/selecao';
import { CopaFilmesService } from 'src/app/services/copa-filmes.service';
import { ApiResponse } from 'src/app/models/api-response';

@Component({
  selector: 'app-selecao',
  templateUrl: './selecao.component.html',
  styleUrls: ['./selecao.component.css']
})
export class SelecaoComponent implements OnInit {
  model: Selecao;

  @Output() eventoGerarCampeonato = new EventEmitter<Array<Filme>>();

  constructor(private copaFilmesService: CopaFilmesService) {
    this.model = new Selecao();
  }

  ngOnInit(): void {
    this.carregarFilmes();
  }

  gerarCampeonato(): void {
    if(this.validarFilmesSelecionados()) {
      this.eventoGerarCampeonato.emit(this.model.filmesSelecionados);
    }
  }

  carregarFilmes(): void {
    this.copaFilmesService
        .obterFilmes()
        .subscribe((filmes: ApiResponse<Array<Filme>>) => {
      this.model.filmes = filmes.data;
    });
  }

  validarFilmesSelecionados(): boolean {
    this.model.flagGerarCampeonato = this.model.filmesTotal == 8
      && this.model.filmesSelecionados.length == 8;
      return this.model.flagGerarCampeonato;
  }

  selecionarFilme($event: Filme): void {
    if($event.selecionado && this.model.filmesTotal < 8) {
      this.model.filmesSelecionados.push($event);
    } else if(!$event.selecionado && this.model.filmesTotal <= 8) {
      this.model.filmesSelecionados =
        this.model.filmesSelecionados.filter(c => c.id != $event.id);
    }
    this.model.filmesTotal += $event.selecionado ? 1 : -1;
    this.validarFilmesSelecionados();
  }
}
