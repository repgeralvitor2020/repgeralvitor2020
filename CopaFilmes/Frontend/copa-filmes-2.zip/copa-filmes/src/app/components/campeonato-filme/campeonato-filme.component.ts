import { Component, OnInit, Input } from '@angular/core';
import { Filme } from 'src/app/models/filme';

@Component({
  selector: 'app-campeonato-filme',
  templateUrl: './campeonato-filme.component.html',
  styleUrls: ['./campeonato-filme.component.css']
})
export class CampeonatoFilmeComponent implements OnInit {
  @Input() id : number;
  @Input() model : Filme;

  constructor() { }

  ngOnInit(): void {
    
  }
}
