import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { campeonatoFilmeComponent } from './campeonato-filme.component';

describe('campeonatoFilmeComponent', () => {
  let component: campeonatoFilmeComponent;
  let fixture: ComponentFixture<campeonatoFilmeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ campeonatoFilmeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(campeonatoFilmeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
