import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Filme } from '../models/filme';
import { ApiResponse } from '../models/api-response';

@Injectable({
    providedIn: 'root'
})
export class CopaFilmesService {
    URL_API: string = "https://localhost:44308/api/home/";
    httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json' })
    }

    constructor(private http: HttpClient) { }

    obterFilmes(): Observable<ApiResponse<Array<Filme>>> {
        return this.http.get<ApiResponse<Array<Filme>>>(`${this.URL_API}ObterFilmes`, this.httpOptions)
        .pipe(
            retry(1),
            catchError(this.handleError)
        );
    }

    gerarCampeonato(filmes: Array<Filme>): Observable<ApiResponse<Array<Filme>>> {
        return this.http.post<ApiResponse<Array<Filme>>>(`${this.URL_API}GerarCampeonato`, filmes, this.httpOptions)
        .pipe(
            retry(1),
            catchError(this.handleError)
        );
    }

    handleError(error: HttpErrorResponse) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
          errorMessage = error.error.message;
        } else {
          errorMessage = `Código do erro: ${error.status}, ` + `menssagem: ${error.message}`;
        }
        console.log(errorMessage);
        return throwError(errorMessage);
    };
}